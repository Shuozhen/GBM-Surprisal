library(patchwork)
library(colorspace)
library(ggpubr)
library(parallel)
library(Seurat)
library(SeuratObject)
library(ggplot2)
library(shiny)
library(tidyverse)
library(purrr)
library(janitor)
library(magrittr)
library(patchwork)
library(stringr)
library(R.utils)
library(layer)
library(dplyr)
library(monocle3)
library(clusterProfiler)
library(org.Hs.eg.db)


samp <-  readRDS("/gpfs/gibbs/project/fan/gil5/Transfer/P4_Core_20250414_NICHES.rds")
samp$CellType_GLSB_manual <- as.character(samp$CellType_GLSB_manual)
Idents(samp) <- "CellType_GLSB_manual"

#Prepare for pseudotime
expression_matrix <- samp@assays$SCT@data
expression_matrix <- as.matrix(expression_matrix)
cds <- new_cell_data_set(expression_matrix, 
                         cell_metadata = samp@meta.data, 
                         gene_metadata = gene_metadata)


# Preprocess and reduce
plot_pc_variance_explained(cds)
cds <- preprocess_cds(cds, num_dim = 15)
cds <- reduce_dimension(cds, reduction_method = "UMAP", preprocess_method = "PCA")
cds <- cluster_cells(cds, reduction_method = "UMAP")

# Learn trajectory graph
cds <- learn_graph(cds)

cols <- c(
  "Perivascular" = "#f17e40",
  "MES-like hypoxia" = "#884922",
  "AC-like" = "#f0cf1b", 
  "Invasive-front" = "#EBD4AB"
)


plot_cells(cds,
           label_groups_by_cluster = FALSE,
           color_cells_by = "CellType_GLSB_manual", cell_size = 0.75) +
  scale_color_manual(values = cols)

#Select the central branch 1 as the root
cds <- order_cells(cds, reduction_method = "UMAP", root_pr_nodes = NULL)

#To plot pseudotime spatially
pseudotime_df <- data.frame(
  cell_id = colnames(cds),
  pseudotime = pseudotime(cds)
)

pseudotime_df <- data.frame(
  cell_id = colnames(cds), 
  pseudotime = pseudotime(cds)
)
samp <- AddMetaData(samp, metadata = pseudotime_df$pseudotime, col.name = "pseudotime")
rownames(samp@meta.data) <- colnames(samp)
SpatialFeaturePlot(samp, features = "pseudotime", shape= 22, image.alpha = 0) +
  scale_fill_viridis_c(option = "plasma")

#Graph test function and GO analysis 
gt <- graph_test(cds, neighbor_graph = "principal_graph", cores = 4)
head(gt[order(gt$q_value), ], 20)
sig_genes <- rownames(subset(gt, q_value < 0.05))
length(sig_genes)


gene_entrez <- bitr(sig_genes, fromType="SYMBOL", toType="ENTREZID", OrgDb=org.Hs.eg.db)
gene_entrez_unique <- gene_entrez %>%
  group_by(SYMBOL) %>%
  slice(1) %>%
  ungroup()

enrich <- enrichGO(
  gene = unique(gene_entrez_unique$ENTREZID),
  OrgDb = org.Hs.eg.db,
  keyType = "ENTREZID",
  ont = "BP",
  pAdjustMethod = "BH",
  pvalueCutoff = 0.1,    # relax cutoff if needed
  qvalueCutoff = 0.3,
  readable = TRUE
)
dotplot(enrich, showCategory = 10) + ggtitle("GO Biological Process Enrichment")
